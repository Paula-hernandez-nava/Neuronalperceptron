﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

namespace neuronalpau
{
    class Program
    {
        static void Main(string[] args)
        {
            double x,x1, x2, y, y2;
            x = 2.5;
            x1 = -3.5 ;
            x2 = 0;
            y = -1;
            y2 = +1;

            //AND
            // x1 | x2 | dx
            // -1 | -1 | -1
            // -1 | +1 | -1
            // +1 | -1 | -1
            // +1 | +1 | +1

            //DOS ELEMENTOS

            // -1.1 + (-1) * 1 + 0.5
            // -1 + (-1) + 0.5
            // -1.5 > 0 NO
            // y = -1
            // y == dx NO

            Console.WriteLine("x1 es mayor que x2 y x2 es igual a y?" + ((x1> x2) && (x2==y)) );
            // -1.1 + 1.1 0.5
            // -1 + 1 + 0.5
            // 0.5 > 0 SI
            // y = +1
            // y == dx

            Console.WriteLine("x es mayor que x2 y x2 es igual a y2?" + ((x > x2) || (x2 == y2)));
            // +1 *2 + (-1) * 0 + 0.5
            // +2 + 0
            // +2 + (-.5)
            // +1.5
            // y = +1
            // y == dx NO
            Console.WriteLine("x1 es menor y2?" + !(x1<y2) );

            //TRES ELEMENTOS

            // -1.1 + (-1) * 1 + 0.5
            // -1 + (-1) + (-1) 0.5
            // -2.5 > 0 NO
            // y = -1
            // y == dx NO

            Console.WriteLine("x1 es mayor que x2 y x2 es igual a y?" + ((x1 > x2) && (x2 == y)));
            // -1.1 + 1.1 0.5
            // -1 + 1 + 1 + 0.5
            // 1.5 > 0 SI
            // y = +1
            // y == dx

            Console.WriteLine("x es mayor que x2 y x2 es igual a y2?" + ((x > x2) || (x2 == y2)));
            // +1 *2 + (-1) * 0 + 0.5
            // +2 + 0 + 1
            // +3 + (-.5)
            // +3.5
            // y = +1
            // y == dx NO
            Console.WriteLine("x1 es menor y2?" + !(x1 < y2));
            

            //CUATRO ELEMENTOS

            
            // -1.1 + (-1) * 1 + 0.5
            // -1 + (-1) + (-1)+ (-1) 0.5
            // -3.5 > 0 NO
            // y = -1
            // y == dx NO

           Console.WriteLine("x1 es mayor que x2 y x2 es igual a y?" + ((x1 > x2) && (x2 == y)));
            // -1.1 + 1.1 0.5
            // -1 + 1 + 1 + 1 + 0.5
            // 2.5 > 0 SI
            // y = +1
            // y == dx

           Console.WriteLine("x es mayor que x2 y x2 es igual a y2?" + ((x > x2) || (x2 == y2)));
            // +1 *2 + (-1) * 0 + 0.5
            // +2 + 0 + 1 + 1
            // +4 + (-.5)
            // +4.5
            // y = +1
            // y == dx NO
            Console.WriteLine("x1 es menor y2?" + !(x1 < y2));

            Console.ReadKey(true);

        }
    }
}
